<?php

	$host='localhost';
	$username = 'root';
	$password = '';
	$db = 'acervo';
	$dbh = new PDO("mysql:host=$host;dbname=$db", $username , $password);

?>