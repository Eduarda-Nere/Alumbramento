<?php

	$host='localhost';
	$username = 'root';
	$password = '';
	$db = 'alumbramento';
	$dbh = new PDO("mysql:host=$host;dbname=$db", $username , $password);

?>

