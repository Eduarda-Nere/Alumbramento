<?php session_start(); ?>
<?php include("login_verificar.php"); ?>
<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <title>Alumbramento</title>
    
    <meta name="description" content="N.Agency - Responisve Landing Page for Agency">
    <meta name="keywords" content="">
    <meta name="author" content="tabthemes">
    
    <!-- Favicons -->
    <link rel="shortcut icon" href="img/alumbramento.png">
    <link rel="apple-touch-icon" sizes="57x57" href="img/alumbramento.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/alumbramento.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/alumbramento.png">
    
    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet" />
    
    <!-- Bootstrap CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    
    <!-- CSS Files For Plugin -->
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/font-awesome/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet" />
    <link href="css/YTPlayer.css" rel="stylesheet" />
    <link href="inc/owlcarousel/css/owl.carousel.min.css" rel="stylesheet" />
    <link href="inc/owlcarousel/css/owl.theme.default.min.css" rel="stylesheet" />
    <link href="inc/revolution/css/settings.css" rel="stylesheet" />
    <link href="inc/revolution/css/layers.css" rel="stylesheet" />
    <link href="inc/revolution/css/navigation.css" rel="stylesheet" />
    
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/menu.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="homepage_slider" data-spy="scroll" data-target=".navbar-fixed-top" data-offset="100">
    
    
    <!-- Preloader -->
    <div id="preloader">
        <div id="spinner"></div>
    </div>
    <!-- End Preloader-->

    
   <?php include("menu_online.php"); ?>

    
    <!-- Start Intro -->
       <section class="parallax-bg overlay-dark" style="background-image:url(img/home.jpg)" data-stellar-background-ratio="0.5">

    <!-- Section Title -->
        <div class="js-height-full container">
            <div class="intro-content white-color text-center vertical-section">
                <div class="vertical-content">
                <h2 class="wow zoomIn m-bottom-20" data-wow-duration="1s" data-wow-delay="0.6s">Alumbramento</h2>
                <div class="testimonial-item text-center">
                    <p class="wow fadeInDown testimonial-desc" data-wow-duration="1s" data-wow-delay="0.8s">"Palavra puxa palavra, uma ideia traz outra, e assim se faz um livro, um governo, ou uma revolução, alguns dizem que assim é que a natureza compôs as suas espécies."</p>
                    <h5 class="testimonial-author">Machado de Assis</h5>
                </div>
                <br><br><a data-scroll href="#temas" class="btn btn-main btn-theme wow fadeInUp" data-wow-delay="0.8s">Sobre</a>
                </div>
            </div>
            <!-- Scroll Down -->
            <div class="scroll-next">
                <a data-scroll href="#temas" class="scroll-down"><i class="fa fa-angle-down scroll-down-icon"></i></a>
            </div>
            <!-- End Scroll Down -->
        </div>
    </section>
    <!-- End Intro -->

    <!-- Start Service -->
    <section id="temas" class="p-top-80 p-bottom-80">
        <div class="container">

            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <!-- Section Title -->
                    <div class="section-title text-center m-bottom-40">
                        <h2 class="wow fadeInDown" data-wow-duration="1s"><strong>Sobre</strong></h2>
                        <div class="divider-center-small wow zoomIn" data-wow-duration="1s" ></div>
                        <p class="section-subtitle wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s"><em>Queremos que você tenha o prazer de conhecer e se aprofundar mais em textos nacionais, afinal a literatura brasileira é uma riqueza.</em></p>
                    </div>
                </div> <!-- /.col -->
            </div>  <!-- /.row -->


            <div class="row">

                <!-- tema Item 1 -->                  
                <div class="col-md-3 col-sm-6 m-bottom-20">              
                    <div class="service wow zoomIn" data-wow-duration="1s" data-wow-delay="0.2s">               
                        <div class="service-icon">
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                        </div>
                        <h4>Literatura Clássica</h4>
                        <div class="service-text">
                            <p>Um clássico é definido pelos valores que é capaz de transmitir e por sua capacidade, inesgotável e sempre atual, de nos transformar – e a si mesmo – a cada leitura.</p>
                        </div>
                    </div>                   
                </div> <!-- /.col -->

                <!-- tema Item 2 -->                  
                <div class="col-md-3 col-sm-6 m-bottom-20">              
                    <div class="service wow zoomIn" data-wow-duration="1s" data-wow-delay="0.2s">               
                        <div class="service-icon">
                            <i class="fa fa-book" aria-hidden="true"></i>
                        </div>
                        <h4>Livros de Vestibular</h4>
                        <div class="service-text">
                            <p>Pensando naqueles alunos que estão estudando para o vestibular organizamos uma lista de obras literárias que são exigidas em vestibulares.<br><br></p>
                        </div>
                    </div>                   
                </div> <!-- /.col -->

                <!-- tema Item 3 -->                  
                <div class="col-md-3 col-sm-6 m-bottom-20">              
                    <div class="service wow zoomIn" data-wow-duration="1s" data-wow-delay="0.2s">              
                        <div class="service-icon">
                            <i class="fa fa-modx" aria-hidden="true"></i>
                        </div>
                        <h4>Antologia</h4>
                        <div class="service-text">
                            <p>Uma coleção escolhida de trechos em prosa e/ou verso do mesmo ou de diferentes autores.<br><br><br><br><br></p>
                        </div>
                    </div>                   
                </div> <!-- /.col -->

                <!-- tema Item 4 -->                  
                <div class="col-md-3 col-sm-6">              
                    <div class="service wow zoomIn" data-wow-duration="1s" data-wow-delay="0.2s">              
                        <div class="service-icon">
                            <i class="fa fa-pencil" aria-hidden="true"></i>
                        </div>
                        <h4>Contemporâneo</h4>
                        <div class="service-text">
                            <p>Caracaterizado principalmente pela sua mistura de tendencias estéticas e união da arte erudita e da arte popular. É aquela que se vive atualmente, do tempo de agora.<br><br></p>
                        </div>
                    </div>                   
                </div> <!-- /.col -->

            </div> <!-- /.row -->

        </div> <!-- /.container -->
    </section>
    <!-- End temas -->


    <!-- Start temas -->
    <section id="sobre" class="light-bg p-top-80 p-bottom-80">
        <div class="container">

            <!-- Section Title -->
            <div class="section-title text-center m-bottom-40">
              <h2 class="wow fadeInDown" data-wow-duration="1s"><strong>Literatura brasileira</strong></h2>
                <div class="divider-center-small wow zoomIn" data-wow-duration="1s" data-wow-delay="0.1s"></div>
                  <em><p class="section-subtitle wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s">Conheça mais sobre o nosso site voltado para livros brasileiros, aqui você irá encontrar vários tipos de gêneros literários nacionais.</em></p></div>

            <!-- temas-filter -->
            <ul class="pf-filter text-center list-inline">
                <li><a href="#" data-filter="*" class="iso-active iso-button">Todos</a></li>
                <li><a href="#" data-filter=".classico" class="iso-button">Clássicos</a></li>
                <li><a href="#" data-filter=".antologia" class="iso-button">Antologias</a></li>
                <li><a href="#" data-filter=".contemporaneo" class="iso-button">Contemporâneos</a></li>
                <li><a href="#" data-filter=".vestibular" class="iso-button">Vestibular</a></li>
            </ul>        

            <!-- temas -->
            <div class="portfolio portfolio-isotope col-4 gutter">

                <!-- temas Item -->
                <div class="pf-item vestibular">
                    <a href="img/portfolio/1.png" class="pf-style lightbox-image mfp-image">
                        <div class="pf-image">
                            <img src="img/portfolio/1.png" alt="">
                            <div class="overlay">
                                <div class="overlay-caption">
                                    <div class="overlay-content">
                                        <div class="pf-info white-color">
                                            <h4 class="pf-title">Machado de Assis</h4>
                                            <p>Quincas Borba</p>
                                        </div> <!-- .pf-info -->
                                    </div> <!-- .overlay-content -->
                                </div> <!-- .overlay-caption -->
                            </div> <!-- .overlay -->
                        </div> <!-- .pf-image -->
                    </a> <!-- .pf-style -->
                </div>

                <!-- temas Item -->
                <div class="pf-item classico">
                    <a href="img/portfolio/2.png" class="pf-style lightbox-image mfp-image">
                        <div class="pf-image">
                            <img src="img/portfolio/2.png" alt="">
                            <div class="overlay">
                                <div class="overlay-caption">
                                    <div class="overlay-content">
                                        <div class="pf-info white-color">
                                            <h4 class="pf-title">Carlos Drummound</h4>
                                            <p>O avesso das coisas</p>
                                        </div> <!-- .pf-info -->
                                    </div> <!-- .overlay-content -->
                                </div> <!-- .overlay-caption -->
                            </div> <!-- .overlay -->
                        </div> <!-- .pf-image -->
                    </a> <!-- .pf-style -->
                </div>

                <!-- temas Item -->
                <div class="pf-item contemporaneo">
                    <a href="img/portfolio/3.png" class="pf-style lightbox-image mfp-image">
                        <div class="pf-image">
                            <img src="img/portfolio/3.png" alt="">
                            <div class="overlay">
                                <div class="overlay-caption">
                                    <div class="overlay-content">
                                        <div class="pf-info white-color">
                                            <h4 class="pf-title">Felipe Rocha</h4>
                                            <p>Todas as flores que não te enviei</p>
                                        </div> <!-- .pf-info -->
                                    </div> <!-- .overlay-content -->
                                </div> <!-- .overlay-caption -->
                            </div> <!-- .overlay -->
                        </div> <!-- .pf-image -->
                    </a> <!-- .pf-style -->
                </div>

                <!-- temas Item -->
                <div class="pf-item classico">
                    <a href="img/portfolio/4.png" class="pf-style lightbox-image mfp-image">
                        <div class="pf-image">
                            <img src="img/portfolio/4.png" alt="">
                            <div class="overlay">
                                <div class="overlay-caption">
                                    <div class="overlay-content">
                                        <div class="pf-info white-color">
                                            <h4 class="pf-title">Lygia Fagundes</h4>
                                            <p>Antes do baile verde</p>
                                        </div> <!-- .pf-info -->
                                    </div> <!-- .overlay-content -->
                                </div> <!-- .overlay-caption -->
                            </div> <!-- .overlay -->
                        </div> <!-- .pf-image -->
                    </a> <!-- .pf-style -->
                </div>

                <!-- temas Item -->
                <div class="pf-item classico">
                    <a href="img/portfolio/5.png" class="pf-style lightbox-image mfp-image">
                        <div class="pf-image">
                            <img src="img/portfolio/5.png" alt="">
                            <div class="overlay">
                                <div class="overlay-caption">
                                    <div class="overlay-content">
                                        <div class="pf-info white-color">
                                            <h4 class="pf-title">Jorge de Lima</h4>
                                            <p>Poemas Negros</p>
                                        </div> <!-- .pf-info -->
                                    </div> <!-- .overlay-content -->
                                </div> <!-- .overlay-caption -->
                            </div> <!-- .overlay -->
                        </div> <!-- .pf-image -->
                    </a> <!-- .pf-style -->
                </div>

                <!-- temas Item -->
                <div class="pf-item classico">
                    <a href="img/portfolio/6.png" class="pf-style lightbox-image mfp-image">
                        <div class="pf-image">
                            <img src="img/portfolio/6.png" alt="">
                            <div class="overlay">
                                <div class="overlay-caption">
                                    <div class="overlay-content">
                                        <div class="pf-info white-color">
                                            <h4 class="pf-title">Erico Verissimo</h4>
                                            <p>Caminhos cruzados</p>
                                        </div> <!-- .pf-info -->
                                    </div> <!-- .overlay-content -->
                                </div> <!-- .overlay-caption -->
                            </div> <!-- .overlay -->
                        </div> <!-- .pf-image -->
                    </a> <!-- .pf-style -->
                </div>

                <!-- temas Item -->
                <div class="pf-item classico">
                    <a href="img/portfolio/7.png" class="pf-style lightbox-image mfp-image">
                        <div class="pf-image">
                            <img src="img/portfolio/7.png" alt="">
                            <div class="overlay">
                                <div class="overlay-caption">
                                    <div class="overlay-content">
                                        <div class="pf-info white-color">
                                            <h4 class="pf-title">Clarisse Lispector</h4>
                                            <p>A hora da estrela</p>
                                        </div> <!-- .pf-info -->
                                    </div> <!-- .overlay-content -->
                                </div> <!-- .overlay-caption -->
                            </div> <!-- .overlay -->
                        </div> <!-- .pf-image -->
                    </a> <!-- .pf-style -->
                </div>

                <!-- temas Item -->
                <div class="pf-item contemporaneo">
                    <a href="img/portfolio/8.png" class="pf-style lightbox-image mfp-image">
                        <div class="pf-image">
                            <img src="img/portfolio/8.png" alt="">
                            <div class="overlay">
                                <div class="overlay-caption">
                                    <div class="overlay-content">
                                        <div class="pf-info white-color">
                                            <h4 class="pf-title">Milton Hatoum</h4>
                                            <p>Dois irmãos</p>
                                        </div> <!-- .pf-info -->
                                    </div> <!-- .overlay-content -->
                                </div> <!-- .overlay-caption -->
                            </div> <!-- .overlay -->
                        </div> <!-- .pf-image -->
                    </a> <!-- .pf-style -->
                </div>

                   
                </div>
            </div> <!-- temas -->        
        </div> <!-- /.container -->
    </section>
    <!-- End temas -->


    <!-- Start Regular Section -->
    <section id="team" class="p-top-80 p-bottom-80">
        <div class="container">
            <div class="row">

                <div class="col-md-6">
                    <!-- Section Title -->
                    <div class="m-bottom-30">
                        <h2 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.1s">Quem somos?</h2>
                        <div class="divider-small wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.1s"></div>
                    </div>

                    <div class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.1s">
                        <p>Olá pessoal! Somos estudantes do Instituto Federal de Educação, Ciência e Tecnologia de São Paulo, Campus Capivari e estamos no 3º ano do Técnico de Informática do ano 2022. Desenvolvemos esse site com o objetivo de aproximar os alunos da literatura brasileira e suas virtudes. <br><br> Por Eduarda Nere, Gabriela Paro, Glaucia Sousa e Kiara Alves. </p>
                    </div>

                </div> <!-- /.col -->

                <div class="col-md-6">

                    <div class="feature-image">
                        <img src="img/team.jpg" alt="Feature Image" class="img-responsive wow fadeInRight" data-wow-duration="1s"/>
                    </div>                  
                    
                </div> <!-- /.col -->

            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </section>
    <!-- End Regular Section -->


    <!-- Start significado -->
    <section id="testimonials" class="parallax-bg overlay-dark p-top-80 p-bottom-80" style="background-image:url(img/sig.jpg)" data-stellar-background-ratio="0.5">

        <!-- Section Title -->
        <div class="section-title text-center white-color m-bottom-40">
            <h2 class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.1s">Alumbramento</h2>
            <div class="divider-center-small divider-white wow zoomIn" data-wow-duration="1s" data-wow-delay="0.1s"></div>
        </div>

        <!-- === significado === -->
        <div id="owl-testimonials" class="owl-carousel owl-theme testimonial text-center white-color">

            <!-- === significado item 1 === -->
            <div class="testimonial-item text-center">
                <p class="testimonial-desc">"Experiências que passamos e que parecem não ser 'deste mundo'. Momentos singulares, impregnados de algo maravilhoso que, de repente, nos toca e encanta. Uma espécie de encantamento faz-nos sentir 'estrangeiros' e, ao mesmo tempo, plenamente nós mesmos, totalmente protegidos em algo familiar. Nestes instantes, desembaraçados dos poderes cotidianos, experimentamos uma impressão de extraordinária liberdade."</p>
                <h5 class="testimonial-author">Por Elpidio Alves Pinheiro </h5>
            </div>

        </div> <!-- /#owl-significado -->

    </section>
    <!-- End significado -->

    <!-- Start Footer -->
    <footer class="site-footer">
        <div class="container">
            <small class="copyright pull-left">Copyrights © 2019 All Rights Reserved By <a href="http://www.tabthemes.com/">tabthemes</a>.</small>
            <div class="social-icon pull-right">
                <a href="https://pt-br.facebook.com/ifspcapivari"><i class="fa fa-facebook"></i></a>
                <a href="https://www.instagram.com/ifspcapivari/"><i class="fa fa-instagram"></i></a>
                <a href="https://cpv.ifsp.edu.br/"><i class="fa fa-google"></i></a>
                <a href="https://www.youtube.com/c/IFSPCapivariOficial?reload=9&app=desktop"><i class="fa fa-youtube"></i></a>
                <a href="http://pergamum.biblioteca.ifsp.edu.br/"><i class="fa fa-globe"></i></a>
            </div>
            <!-- /social-icon -->
        </div>
        <!-- /container -->
    </footer>
    <!-- End Footer -->


    <!-- Back to top -->
    <a href="#" id="back-to-top" title="Back to top"><i class="fa fa-angle-up"></i></a>
    <!-- /Back to top -->

    
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    
    <!-- Bootstrap -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    
    <!-- Components Plugin -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/smooth-scroll.js"></script>
    <script src="js/jquery.appear.js"></script>
    <script src="js/jquery.countTo.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/jquery.mb.YTPlayer.js"></script>
    <script src="js/retina.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="inc/owlcarousel/js/owl.carousel.min.js"></script>
    <script src="inc/revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="inc/revolution/js/jquery.themepunch.revolution.min.js"></script>

    <!-- Contact Form -->
    <script src="js/contact.js"></script>
    
    <!-- Custom Plugin -->
    <script src="js/custom.js"></script>

    <!-- RS Plugin Extensions -->
    <script src="inc/revolution/js/extensions/revolution.extension.video.min.js"></script>
    <script src="inc/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="inc/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script src="inc/revolution/js/extensions/revolution.extension.actions.min.js"></script>
    <script src="inc/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="inc/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="inc/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script src="inc/revolution/js/extensions/revolution.extension.migration.min.js"></script>
    <script src="inc/revolution/js/extensions/revolution.extension.parallax.min.js"></script>


    <script>
      var tpj = jQuery;

      var revapi280;
      tpj(document).ready(function() {
          if (tpj("#rev_slider_nagency").revolution == undefined) {
              revslider_showDoubleJqueryError("#rev_slider_nagency");
          } else {
              revapi280 = tpj("#rev_slider_nagency").show().revolution({
                  sliderType: "standard",
                  sliderLayout: "fullscreen",
                  dottedOverlay: "none",
                  delay: 90000,
                  navigation: {
                    keyboardNavigation:"off",
                    keyboard_direction: "horizontal",
                    mouseScrollNavigation:"off",
                    onHoverStop:"off",
                    touch:{
                      touchenabled:"on",
                      swipe_threshold: 75,
                      swipe_min_touches: 1,
                      swipe_direction: "horizontal",
                      drag_block_vertical: false
                    }
                    ,
                    arrows: {
                          style: "uranus",
                          enable: true,
                          hide_onmobile: true,
                          hide_under: 496,
                          hide_onleave: true,
                          hide_delay: 200,
                          hide_delay_mobile: 1200,
                          tmp: '',
                          left: {
                              h_align: "left",
                              v_align: "center",
                              h_offset: 20,
                              v_offset: 0
                          },
                          right: {
                              h_align: "right",
                              v_align: "center",
                              h_offset: 20,
                              v_offset: 0
                          }
                      }
                  },
                  responsiveLevels: [1200, 991, 767, 480],
                  visibilityLevels: [1200, 991, 767, 480],
                  gridwidth: [1200, 991, 767, 480],
                  gridheight: [868, 768, 960, 720],
                  lazyType: "none",
                  parallax: {
                    type:"mouse+scroll",
                    origo:"slidercenter",
                    speed:2000,
                    levels:[2,3,4,5,6,7,12,16,10,50],
                    disable_onmobile:"on"
                  },
                  shadow: 0,
                  spinner: "spinner2",
                  autoHeight: "off",
                  fullScreenAutoWidth: "off",
                  fullScreenAlignForce: "off",
                  fullScreenOffsetContainer: "",
                  fullScreenOffset: "0",
                  disableProgressBar: "on",
                  hideThumbsOnMobile: "off",
                  hideSliderAtLimit: 0,
                  hideCaptionAtLimit: 0,
                  hideAllCaptionAtLilmit: 0,
                  debugMode: false,
                  fallbacks: {
                      simplifyAll: "off",
                      disableFocusListener: false,
                  }
              });
          }
      }); /*ready*/
  </script>

  </body>
</html>